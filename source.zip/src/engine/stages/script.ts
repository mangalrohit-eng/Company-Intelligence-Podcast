/**
 * Stage 10: Script & Polish
 * Generate narrative script from outline and summaries
 */

import { Script, ThematicOutline, TopicSummary, CompetitorContrast } from '@/types/shared';
import { IEventEmitter } from '@/utils/event-emitter';
import { ILlmGateway } from '@/gateways/types';
import { logger } from '@/utils/logger';

export interface ScriptOutput {
  script: Script;
  stats: {
    wordCount: number;
    estimatedDurationMinutes: number;
    bridgeCount: number;
    sectionWordCounts: Record<string, number>;
  };
}

export class ScriptStage {
  constructor(private llmGateway: ILlmGateway) {}

  async execute(
    outline: ThematicOutline,
    summaries: TopicSummary[],
    contrasts: CompetitorContrast[],
    targetDurationMinutes: number,
    emitter: IEventEmitter,
    podcastTitle?: string,
    podcastSubtitle?: string,
    podcastDescription?: string
  ): Promise<ScriptOutput> {
    await emitter.emit('script', 0, 'Starting script generation');

    const targetWords = Math.round(targetDurationMinutes * 150);

    // Build podcast context section if metadata is available
    const podcastContext = [];
    if (podcastTitle) {
      podcastContext.push(`Title: ${podcastTitle}`);
    }
    if (podcastSubtitle) {
      podcastContext.push(`Subtitle: ${podcastSubtitle}`);
    }
    if (podcastDescription) {
      podcastContext.push(`Description: ${podcastDescription}`);
    }
    const podcastContextStr = podcastContext.length > 0 
      ? `\nPodcast Context:\n${podcastContext.join('\n')}\n` 
      : '';

    // Construct context for LLM
    const context = `
${podcastContextStr}Theme: ${outline.theme}
Subthemes: ${outline.subThemes.join(', ')}

Sections:
${outline.sections.map((s) => `- ${s.title}: ${s.bulletPoints.join('; ')}`).join('\n')}

Topic Summaries:
${summaries.map((s) => `${s.topicName}: ${s.paragraph}`).join('\n\n')}

Competitor Contrasts:
${contrasts.map((c) => c.sentences.join(' ')).join('\n\n')}

Target length: ~${targetWords} words
    `.trim();

    await emitter.emit('script', 30, 'Generating narrative script');

    // Build title reference for system prompt
    const titleReference = podcastTitle 
      ? `Use the EXACT podcast title: "${podcastTitle}"${podcastSubtitle ? ` (subtitle: "${podcastSubtitle}")` : ''} - do NOT make up a different show name`
      : 'Use appropriate business intelligence terminology';

    // Executive-focused system prompt: high density, direct, no filler
    const systemPrompt = `You are a scriptwriter for a business intelligence podcast targeted at senior executives. 

CRITICAL REQUIREMENTS:
- ${titleReference}
${podcastDescription ? `- Align content with the podcast's purpose: "${podcastDescription}"` : ''}
- Write for C-suite executives: high information density, direct statements, zero filler
- Eliminate empty jargon, buzzwords, and fluff phrases like "let's dive in", "without further ado", "it's worth noting"
- Every sentence must deliver substantive information or insight
- Use precise business language and concrete data points
- Avoid conversational padding, unnecessary transitions, or rhetorical questions
- Get straight to the point in every segment
- Maintain professional tone while being concise and actionable

STYLE GUIDELINES:
- Lead with the most important information first
- Use active voice and strong verbs
- Include specific numbers, percentages, and metrics when available
- Connect insights to business implications immediately
- No "welcome to" or "thanks for listening" - start with content immediately`;

    const userPrompt = podcastTitle 
      ? `Write a podcast script for "${podcastTitle}"${podcastSubtitle ? ` (${podcastSubtitle})` : ''} based on the following outline and summaries. ${podcastDescription ? `The podcast's purpose: ${podcastDescription}. ` : ''}Target length: ~${targetWords} words. Start directly with the content - no introduction or show name announcement.\n\n${context}`
      : `Write a podcast script based on the following outline and summaries. Target length: ~${targetWords} words.\n\n${context}`;

    const response = await this.llmGateway.complete({
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: userPrompt,
        },
      ],
      temperature: 0.7, // Slightly lower for more focused, direct output
      maxTokens: Math.round(targetWords * 1.5),
    });

    await emitter.emit('script', 70, 'Polishing script');

    const narrative = response.content;
    const wordCount = narrative.split(/\s+/).length;
    const durationEstimateSeconds = Math.round((wordCount / 150) * 60);
    const estimatedDurationMinutes = durationEstimateSeconds / 60;

    // Count bridges (assume patterns like "moving on", "turning to", transitions)
    const bridgePatterns = /\b(moving on|turning to|next|meanwhile|however|furthermore|in addition|moreover)\b/gi;
    const bridgeCount = (narrative.match(bridgePatterns) || []).length;

    // Calculate section word counts (simplified - split by paragraphs)
    const sections = narrative.split('\n\n').filter(s => s.trim().length > 0);
    const sectionWordCounts: Record<string, number> = {};
    outline.sections.forEach((section, idx) => {
      const sectionText = sections[idx] || '';
      sectionWordCounts[section.title] = sectionText.split(/\s+/).length;
    });

    // Extract bound evidence (simplified - in real impl, track exact references)
    const boundEvidence: Record<string, string> = {};
    for (const summary of summaries) {
      boundEvidence[summary.onAirStat.evidenceId] = summary.onAirStat.span;
      boundEvidence[summary.onAirQuote.evidenceId] = summary.onAirQuote.span;
    }

    const stats = {
      wordCount,
      estimatedDurationMinutes,
      bridgeCount,
      sectionWordCounts,
    };

    logger.info('Script stage complete', stats);

    await emitter.emit('script', 100, `Script complete: ${wordCount} words`, 'info', stats);

    return {
      script: {
        narrative,
        boundEvidence,
        durationEstimateSeconds,
      },
      stats,
    };
  }
}

